export const recallRuntime={"apiOrigin":"https://recall-nqmz.onrender.com","websiteOrigin":"https://recall-nqmz.onrender.com"};
